document.addEventListener('DOMContentLoaded', function () {
    const params = new URLSearchParams(window.location.search);
    const pacote = params.get('pacote');
    const detalhesContainer = document.getElementById('detalhes-container');

    const pacotesDetalhes = {
        bronze: {
            titulo: "Pacote Bronze",
            descricao: "•	01 Corte tradicional bovino (Contrafilé ou Entrecoche). <br> •	Linguiça Toscana tradicional. <br>•	Coxinha da asa . <br> •	Pão de Alho. <br>•	Kafta. <br> •	Arroz branco. <br> •	01 tipo de salada: simples (alface e tomate), maionese. <br> •	Vinagrete. <br> •	Farofa pronta. <br> •	Carvão. <br> •	Descartáveis (opcional). <br> •	Bebidas – (opcional, marca a escolher). ",
            imagem: "images/bronze1.jpg"
        },
        prata: {
            titulo: "Pacote Prata",
            descricao:  `
            •	02 Corte bovino (Contrafilé, Entrecoche, Fraldinha, Maninha, Bife Chorizo)<br>
            •	Linguiça Toscana tradicional.<br>
            •	Coxinha da asa, Tulipinha, coração.<br>
            •	Pão de Alho.<br>
            •	Queijo coalho.<br>
            •	Kafta.<br>
            •	Arroz Branco
            •	02 tipos de saladas: simples (alface, tomate, pepino, rúcula) ou antepasto de beringela ou maionese.<br>
            •	Vinagrete.<br>
            •	Farofa pronta.<br>
            •	Carvão.<br>
            •	Descartáveis (opcional).<br>
            •	Bebidas – (opcional, marca a escolher).<br>
            
        `,
            imagem: "images/prata1.jpg"
        },
        ouro: {
            titulo: "Pacote Ouro",
            descricao: `
            •	03 Corte bovino (Contrafilé, Entrecoche, Fraldinha, Maninha, Bife Chorizo, Picanha (linha premium), Filé Mignon, Baby bife, Bife ancho).<br>
            •	Linguiça tradicional e Cuiabana.<br>
            •	Coxinha da asa, Tulipinha, coração.<br>
            •	Pão de Alho.<br>
            •	Queijo coalho.<br>
            •	Queijo Provolone.<br>
            •	Medalhão de queijo.<br>
            •	Kafta.<br>
            •	01 corte suíno (picanha ou file mignon) ou bovino (Cupim no bafo) - assado de forma diferenciada.<br>
            •	Arroz Branco.<br>
            •	3 tipos de saladas: simples (alface, tomate, pepino, rúcula) ou antepasto de berinjela ou maionese ou salpicão de frango.<br>
            •	Vinagrete.<br>
            •	Farofa pronta.<br>
            •	Descartáveis (opcional).<br>
            •	Bebidas – (opcional, incluso todo os tipos).<br>
           ` ,
            imagem: "images/ouro1.jpg"
        }
    };

    const pacoteDetalhes = pacotesDetalhes[pacote];

    if (pacoteDetalhes) {
        detalhesContainer.innerHTML = `
            <div class="pacote-detalhes">
                <img src="${pacoteDetalhes.imagem}" alt="${pacoteDetalhes.titulo}">
                <h2>${pacoteDetalhes.titulo}</h2>
                <p>${pacoteDetalhes.descricao}</p>
                <button onclick="window.history.back()">Voltar</button>
            </div>
        `;
    } else {
        detalhesContainer.innerHTML = "<p>Pacote não encontrado.</p>";
    }
});
