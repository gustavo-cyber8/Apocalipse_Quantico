function verDetalhes(pacote) {
    window.location.href = `detalhes.html?pacote=${pacote}`;
}
